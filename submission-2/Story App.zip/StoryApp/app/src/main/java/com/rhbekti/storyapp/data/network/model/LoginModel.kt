package com.rhbekti.storyapp.data.network.model

data class LoginModel(
    var email: String = "",
    var password: String = ""
)