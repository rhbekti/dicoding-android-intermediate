package com.rhbekti.storyapp.data.network.model

data class RegisterModel (
    var name: String = "",
    var email: String = "",
    var password: String = ""
)